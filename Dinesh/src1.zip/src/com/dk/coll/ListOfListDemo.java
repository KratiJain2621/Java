package com.dk.coll;

import java.util.List;

public class ListOfListDemo
{
	
	public static void main(String[] args)
	{
		String str = "This is java string for you";
		List<List<Character>> listOfList = getRepeatedAndNonRepeatedChars(str);
		//T h j v t 
		//i s ' ' a r
	}

	private static List<List<Character>> getRepeatedAndNonRepeatedChars(String str)
	{
		return null;
	}
	

}
