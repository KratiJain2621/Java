package com.dk.coll;

import java.util.ArrayList;
import java.util.List;

public class SomeTest
{
	public static void main(String[] args)
	{
		List<String> list = new ArrayList<>();
		boolean contains = list.contains(4);
		System.out.print(contains);

	}

}
